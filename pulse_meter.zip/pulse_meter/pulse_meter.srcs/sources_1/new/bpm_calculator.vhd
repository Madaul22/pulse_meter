----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 10:51:28 PM
-- Design Name: 
-- Module Name: bpm_calculator - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity bpm_calculator is
Port(
clk :in std_logic;
rst : in std_logic;
start : in std_logic;
durata_ms : in integer range 1 to 60000;
done : out std_logic;
bpm : out integer range 0 to 9999
);
end bpm_calculator;

architecture Behavioral of bpm_calculator is
signal count_down : integer range 0 to 60000 := 0;
signal reloads : integer range 0 to 9999:= 0;
signal  running : std_logic :='0';
begin
process(clk, rst)
    begin
    if rst = '1' then
        count_down <= 0;
        reloads <= 0;
        running <='0';
        done <='0';
    elsif rising_edge(clk) then
        if start = '1' then
            count_down <= durata_ms;
            reloads <= 0;
            running <= '1';
            done <='0';
        elsif running = '1' then
            if count_down > 0 then
                count_down <= count_down-1;
            else
                reloads <= reloads+1;
                if reloads * durata_ms >= 60000 then
                    running<='0';
                    done<='1';
                else
                    count_down<= durata_ms;
                end if;
             end if;
         end if;
    end if;
    end process;
bpm <= reloads;
end Behavioral;
