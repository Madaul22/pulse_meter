----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 11:21:04 PM
-- Design Name: 
-- Module Name: seven_segment_display - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity seven_segment_display is
    Port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        bcd3    : in  std_logic_vector(3 downto 0);
        bcd2    : in  std_logic_vector(3 downto 0);
        bcd1    : in  std_logic_vector(3 downto 0);
        bcd0    : in  std_logic_vector(3 downto 0);
        an      : out std_logic_vector(3 downto 0); 
        seg     : out std_logic_vector(6 downto 0)  
    );
end seven_segment_display;

architecture Behavioral of seven_segment_display is
    signal refresh_counter : integer range 0 to 49999 := 0;
    signal digit_index      : integer range 0 to 3 := 0;
    signal current_digit    : std_logic_vector(3 downto 0);

    function bcd_to_segment(bcd : std_logic_vector(3 downto 0)) return std_logic_vector is
        variable segs : std_logic_vector(6 downto 0);
    begin
        case bcd is
            when "0000" => segs := "0000001";
            when "0001" => segs := "1001111"; 
            when "0010" => segs := "0010010"; 
            when "0011" => segs := "0000110"; 
            when "0100" => segs := "1001100";
            when "0101" => segs := "0100100"; 
            when "0110" => segs := "0100000"; 
            when "0111" => segs := "0001111"; 
            when "1000" => segs := "0000000"; 
            when "1001" => segs := "0000100"; 
            when others => segs := "1111111"; 
        end case;
        return segs;
    end function;

begin
    process(clk, rst)
    begin
        if rst = '1' then
            refresh_counter <= 0;
            digit_index <= 0;
        elsif rising_edge(clk) then
            if refresh_counter = 49999 then
                refresh_counter <= 0;
                digit_index <= (digit_index + 1) mod 4;
            else
                refresh_counter <= refresh_counter + 1;
            end if;
        end if;
    end process;

    process(digit_index, bcd3, bcd2, bcd1, bcd0)
    begin
        case digit_index is
            when 0 =>
                current_digit <= bcd0;
                an <= "1110";
            when 1 =>
                current_digit <= bcd1;
                an <= "1101";
            when 2 =>
                current_digit <= bcd2;
                an <= "1011";
            when 3 =>
                current_digit <= bcd3;
                an <= "0111";
            when others =>
                current_digit <= "0000";
                an <= "1111";
        end case;
    end process;

    seg <= bcd_to_segment(current_digit);

end Behavioral;