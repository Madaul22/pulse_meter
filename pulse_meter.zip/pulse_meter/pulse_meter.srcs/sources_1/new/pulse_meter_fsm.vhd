----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 10:12:52 PM
-- Design Name: 
-- Module Name: pulse_meter_fsm - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;   

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity pulse_meter_fsm is
Port(clk : in   std_logic;
     rst : in   std_logic;
     button :   in std_logic ;
     current_state :    out std_logic_vector(2 downto 0)  
);
end pulse_meter_fsm;

architecture Behavioral of pulse_meter_fsm is
    type state_type is (Start,SwOn,Inceput,Count,Final,Pulse,Afisaj);
    signal state,next_state : state_type;
begin
process (state,clk)
begin
    if rst = '1' then
        state <= Start;
    elsif rising_edge(clk) then
        state <= next_state;
    end if;
end process ;

process (state, button)
begin
    case state is
        when Start=>
            if button = '1' then
                next_state <=SwOn;
            else
                next_state <= Start;
            end if;
         when SwOn =>
            if button ='0' then
                next_state <= Inceput;
            else
                next_state<=SwOn;
            end if;
         when Inceput =>
            next_state <= count;
         when Count =>
            if button = '1' then
                next_state <= Final;
            else
                next_state <= Count;
            end if;
          when Final =>
            if button = '0' then
                next_state <= Pulse;
            else
                next_state <= Final;
            end if;
          when Pulse =>
            next_state <=Afisaj;
          when Afisaj =>
            next_state <= Start;
          when others =>
            next_state <=Start;
          end case;
end process;
end Behavioral;
