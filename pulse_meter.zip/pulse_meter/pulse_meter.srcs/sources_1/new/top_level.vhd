----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 11:31:19 PM
-- Design Name: 
-- Module Name: top_level - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_level is
    Port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        button  : in  std_logic;
        an      : out std_logic_vector(3 downto 0);
        seg     : out std_logic_vector(6 downto 0)
    );
end top_level;

architecture Behavioral of top_level is

    signal tick_1ms      : std_logic;
    signal fsm_state     : std_logic_vector(2 downto 0);
    signal enable_count  : std_logic;
    signal durata_ms     : integer range 0 to 60000 := 0;
    signal bpm           : integer range 0 to 9999 := 0;
    signal calc_done     : std_logic;
    signal bcd0, bcd1, bcd2, bcd3 : std_logic_vector(3 downto 0);
    signal convert_done  : std_logic;
    signal start_calc    : std_logic;
    signal start_convert : std_logic;

begin
    clkdiv: entity work.clock_divider_1kHz
        port map(clk => clk, rst => rst, tick_1ms => tick_1ms);

    fsm: entity work.pulse_meter_fsm
        port map(
            clk => clk,
            rst => rst,
            button => button,
            current_state => fsm_state
        );

    enable_count <= '1' when fsm_state = "011" else '0';

    dur: entity work.duration_counter
        port map(
            clk => clk,
            rst => rst,
            tick_1ms => tick_1ms,
            enable => enable_count,
            durata_ms => durata_ms
        );

    start_calc <= '1' when fsm_state = "100" else '0';

    calc: entity work.bpm_calculator
        port map(
            clk => clk,
            rst => rst,
            start => start_calc,
            durata_ms => durata_ms,
            done => calc_done,
            bpm => bpm
        );
    start_convert <= '1' when fsm_state = "101" else '0';
   
    conv: entity work.bin_to_bcd
        port map(
            clk => clk,
            rst => rst,
            bin_in => bpm,
            start => start_convert,
            done => convert_done,
            bcd3 => bcd3,
            bcd2 => bcd2,
            bcd1 => bcd1,
            bcd0 => bcd0
        );

    display: entity work.seven_segment_display
        port map(
            clk => clk,
            rst => rst,
            bcd3 => bcd3,
            bcd2 => bcd2,
            bcd1 => bcd1,
            bcd0 => bcd0,
            an => an,
            seg => seg
        );

end Behavioral;