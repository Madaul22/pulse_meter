----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 10:44:16 PM
-- Design Name: 
-- Module Name: duration_counter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.numeric_std ;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity duration_counter is
Port(
clk : in std_logic;
rst : in std_logic;
tick_1ms : in std_logic;
enable : in std_logic;
durata_ms : out integer range 0 to 60000
);
end duration_counter;

architecture Behavioral of duration_counter is
    signal count : integer range 0 to 60000 := 0;
begin
    process(clk, rst)
    begin
        if rst = '1' then
            count <=0;
        elsif rising_edge(clk) then
            if tick_1ms = '1' then
                if enable = '1' then
                    count <=count+1;
                end if;
            end if;
        end if;
    end process;
durata_ms <= count;
end Behavioral;
