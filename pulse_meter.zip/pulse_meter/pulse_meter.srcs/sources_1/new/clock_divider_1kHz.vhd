----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 10:35:56 PM
-- Design Name: 
-- Module Name: clock_divider_1kHz - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.numeric_std.ALL; 

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity clock_divider_1kHz is
Port(
clk : in std_logic;
rst : in std_logic;
tick_1ms :out std_logic
);
end clock_divider_1kHz;

architecture Behavioral of clock_divider_1kHz is
    constant MAX_COUNT : integer:= 100_000-1;
    signal count : integer range 0 to MAX_COUNT := 0;
    signal tick : std_logic := '0';
    begin
process(clk , rst)
    begin
        if rst = '1' then
            count <= 0 ;
            tick <='0';
        elsif rising_edge(clk) then
            if count = MAX_COUNT then
                count <=0;
                tick<='1';
            else
                count <= count +1;
                tick<='0';
            end if;
        end if;
end process;
    tick_1ms <= tick;
end Behavioral;
