----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 11:04:51 PM
-- Design Name: 
-- Module Name: bin_to_bcd - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity bin_to_bcd is
    Port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        bin_in   : in  integer range 0 to 9999;
        start    : in  std_logic;
        done     : out std_logic;
        bcd3     : out std_logic_vector(3 downto 0);
        bcd2     : out std_logic_vector(3 downto 0); 
        bcd1     : out std_logic_vector(3 downto 0); 
        bcd0     : out std_logic_vector(3 downto 0)  
    );
end bin_to_bcd;

architecture Behavioral of bin_to_bcd is
    type state_type is (Idle, Convert, Finish);
    signal state : state_type := Idle;

    signal shift_reg : std_logic_vector(19 downto 0); 
    signal count     : integer range 0 to 16 := 0;

    signal bcd : std_logic_vector(15 downto 0);
begin

    process(clk, rst)
    begin
        if rst = '1' then
            state <= Idle;
            done  <= '0';
            bcd   <= (others => '0');
        elsif rising_edge(clk) then
            case state is
                when Idle =>
                    if start = '1' then
                        shift_reg <= std_logic_vector(to_unsigned(bin_in, 20));
                        count <= 0;
                        state <= Convert;
                        done <= '0';
                    end if;

                when Convert =>
                    if count = 16 then
                        state <= Finish;
                    else
                        for i in 0 to 3 loop
                            if bcd((i*4)+3 downto i*4) > "0100" then
                                bcd((i*4)+3 downto i*4) <= std_logic_vector(unsigned(bcd((i*4)+3 downto i*4)) + 3);
                            end if;
                        end loop;
                        bcd <= bcd(14 downto 0) & shift_reg(19);
                        shift_reg <= shift_reg(18 downto 0) & '0';
                        count <= count + 1;
                    end if;

                when Finish =>
                    state <= Idle;
                    done <= '1';
            end case;
        end if;
    end process;
    bcd3 <= bcd(15 downto 12);
    bcd2 <= bcd(11 downto 8);
    bcd1 <= bcd(7 downto 4);
    bcd0 <= bcd(3 downto 0);

end Behavioral;
